using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.Data.Sqlite;
using System.Net;

// ====================== НАСТРОЙКА БАЗЫ ДАННЫХ ======================

const string connectionString = "Data Source=college.db";
Database.Initialize(connectionString);

var builder = WebApplication.CreateBuilder(args);
var app = builder.Build();

var settings = new CollegeSettings("Колледж информационных технологий", "2026–2027");

string H(string? value) => WebUtility.HtmlEncode(value ?? "");

string Page(string title, string body)
{
    return $$"""
    <!DOCTYPE html>
    <html lang="ru">
    <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>{{H(title)}}</title>
    <style>
    body { font-family: Arial, sans-serif; background: #f3f5f8; margin: 0; color: #222; }
    header { background: #243b55; color: white; padding: 22px 7%; }
    nav { background: white; padding: 14px 7%; display: flex; gap: 16px; flex-wrap: wrap; box-shadow: 0 2px 6px #ddd; }
    nav a { color: #243b55; text-decoration: none; font-weight: bold; }
    main { max-width: 1000px; margin: 28px auto; background: white; padding: 26px; border-radius: 12px; box-shadow: 0 2px 10px #ddd; }
    table { border-collapse: collapse; width: 100%; margin-top: 15px; }
    td, th { border: 1px solid #ddd; padding: 10px; text-align: left; }
    th { background: #eaf0f6; }
    input, button { padding: 10px; margin: 5px 3px; border: 1px solid #bbb; border-radius: 6px; }
    button { background: #243b55; color: white; cursor: pointer; }
    .card { padding: 16px; background: #eef3f8; border-radius: 8px; margin: 10px 0; }
    .muted { color: #666; }
    .danger { color: #b00020; }
    </style>
    </head>
    <body>
    <header>
      <h1>{{H(settings.CollegeName)}}</h1>
      <div>Оқу жылы: {{H(settings.AcademicYear)}}</div>
    </header>
    <nav>
      <a href="/">Главная</a>
      <a href="/login">Авторизация</a>
      <a href="/students">Студенты</a>
      <a href="/teachers">Преподаватели</a>
      <a href="/groups">Группы</a>
      <a href="/grades">Оценки</a>
      <a href="/attendance">Посещаемость</a>
      <a href="/admin">Админ-панель</a>
    </nav>
    <main>{{body}}</main>
    </body>
    </html>
    """;
}

string Table(string headers, IEnumerable<string> rows) =>
    $"<table><tr>{headers}</tr>{string.Join("", rows)}</table>";

// ====================== СТРАНИЦЫ САЙТА (ЗАДАНИЕ 30) ======================

app.MapGet("/", () =>
{
    var studentCount = Database.Count(connectionString, "Students");
    var teacherCount = Database.Count(connectionString, "Teachers");
    var groupCount = Database.Count(connectionString, "StudyGroups");

    return Results.Content(Page("Главная", $"""
        <h2>Добро пожаловать!</h2>
        <p>Это учебное веб-приложение колледжа.</p>
        <div class="card">Информация сохраняется в базе данных SQLite.</div>
        <p>Студентов: <b>{studentCount}</b></p>
        <p>Преподавателей: <b>{teacherCount}</b></p>
        <p>Групп: <b>{groupCount}</b></p>
        <p class="muted">Тестовый вход: admin / 12345.</p>
        """), "text/html; charset=utf-8");
});

app.MapGet("/login", () => Results.Content(Page("Авторизация", """
    <h2>Авторизация</h2>
    <form method="post" action="/login">
      <label>Логин:</label><br><input name="login" required><br>
      <label>Пароль:</label><br><input name="password" type="password" required><br>
      <button type="submit">Войти</button>
    </form>
    <p class="muted">Тестовый логин: admin, пароль: 12345.</p>
    """), "text/html; charset=utf-8"));

app.MapPost("/login", async (HttpContext context) =>
{
    var form = await context.Request.ReadFormAsync();
    bool valid = Database.CheckLogin(connectionString, form["login"].ToString(), form["password"].ToString());

    if (valid)
    {
        context.Response.Cookies.Append("college_auth", "admin",
            new CookieOptions { HttpOnly = true, SameSite = SameSiteMode.Lax });
        return (IResult)Results.Redirect("/admin");
    }

    return (IResult)Results.Content(Page("Ошибка",
        "<h2 class='danger'>Неверный логин или пароль</h2><a href='/login'>Попробовать снова</a>"),
        "text/html; charset=utf-8");
});

app.MapGet("/students", () =>
{
    var rows = Database.GetStudents(connectionString).Select(s =>
        $"<tr><td>{s.Id}</td><td>{H(s.Name)}</td><td>{H(s.Surname)}</td><td>{s.Age}</td><td>{H(s.GroupName)}</td></tr>");

    string form = """
      <h3>Добавить студента</h3>
      <form method="post" action="/students/add">
        <input name="name" placeholder="Имя" required>
        <input name="surname" placeholder="Фамилия" required>
        <input name="age" type="number" min="15" max="70" placeholder="Возраст" required>
        <input name="groupName" placeholder="Группа" required>
        <button type="submit">Добавить</button>
      </form>
      """;

    return Results.Content(Page("Студенты", "<h2>Список студентов</h2>" +
        form + Table("<th>ID</th><th>Имя</th><th>Фамилия</th><th>Возраст</th><th>Группа</th>", rows)),
        "text/html; charset=utf-8");
});

app.MapPost("/students/add", async (HttpContext context) =>
{
    var form = await context.Request.ReadFormAsync();
    string name = form["name"].ToString().Trim();
    string surname = form["surname"].ToString().Trim();
    string groupName = form["groupName"].ToString().Trim();

    if (!int.TryParse(form["age"], out int age) || age < 15 || age > 70 ||
        name.Length == 0 || surname.Length == 0 || groupName.Length == 0)
    {
        return Results.Content(Page("Ошибка", "<p class='danger'>Проверьте данные. Возраст должен быть от 15 до 70.</p><a href='/students'>Назад</a>"),
            "text/html; charset=utf-8");
    }

    Database.AddStudent(connectionString, name, surname, age, groupName);
    return Results.Redirect("/students");
});

app.MapGet("/teachers", () =>
{
    var rows = Database.GetTeachers(connectionString).Select(t =>
        $"<tr><td>{H(t.Name)}</td><td>{H(t.Surname)}</td><td>{H(t.Subject)}</td><td>{t.Experience}</td></tr>");

    return Results.Content(Page("Преподаватели", "<h2>Список преподавателей</h2>" +
        Table("<th>Имя</th><th>Фамилия</th><th>Предмет</th><th>Стаж</th>", rows)),
        "text/html; charset=utf-8");
});

app.MapGet("/groups", () =>
{
    var rows = Database.GetGroups(connectionString).Select(g =>
        $"<tr><td>{H(g.GroupName)}</td><td>{g.Course}</td><td>{g.StudentCount}</td></tr>");

    return Results.Content(Page("Группы", "<h2>Учебные группы</h2>" +
        Table("<th>Название группы</th><th>Курс</th><th>Количество студентов</th>", rows)),
        "text/html; charset=utf-8");
});

app.MapGet("/grades", () =>
{
    var grades = Database.GetGrades(connectionString);
    var rows = grades.Select((g, i) =>
        $"<tr><td>{i + 1}</td><td>{H(g.StudentName)}</td><td>{g.Grade}</td><td>{H(g.Subject)}</td></tr>");
    double average = grades.Count == 0 ? 0 : grades.Average(g => g.Grade);

    return Results.Content(Page("Оценки", "<h2>Электронный журнал оценок</h2>" +
        Table("<th>№</th><th>Студент</th><th>Оценка</th><th>Предмет</th>", rows) +
        $"<p><b>Средний балл:</b> {average:0.00}</p>"), "text/html; charset=utf-8");
});

app.MapGet("/attendance", () =>
{
    var records = Database.GetAttendance(connectionString);
    var rows = records.Select(a =>
        $"<tr><td>{H(a.StudentName)}</td><td>{(a.Present ? "Присутствовал" : "Отсутствовал")}</td></tr>");
    double percent = records.Count == 0 ? 0 : records.Count(a => a.Present) * 100.0 / records.Count;

    return Results.Content(Page("Посещаемость", "<h2>Посещаемость студентов</h2>" +
        Table("<th>Студент</th><th>Статус</th>", rows) +
        $"<p><b>Процент посещаемости:</b> {percent:0.0}%</p>"), "text/html; charset=utf-8");
});

app.MapGet("/admin", (HttpContext context) =>
{
    if (!context.Request.Cookies.ContainsKey("college_auth"))
        return (IResult)Results.Redirect("/login");

    return (IResult)Results.Content(Page("Административная панель", $"""
        <h2>Административная панель</h2>
        <div class="card">Управление данными колледжа.</div>
        <ul>
          <li>Студентов: {Database.Count(connectionString, "Students")}</li>
          <li>Преподавателей: {Database.Count(connectionString, "Teachers")}</li>
          <li>Групп: {Database.Count(connectionString, "StudyGroups")}</li>
        </ul>
        <form method="post" action="/logout"><button>Выйти</button></form>
        """), "text/html; charset=utf-8");
});

app.MapPost("/logout", (HttpContext context) =>
{
    context.Response.Cookies.Delete("college_auth");
    return Results.Redirect("/");
});

app.Run();

// ====================== КЛАССЫ ЗАДАНИЙ 1–29 ======================

public class Person
{
    protected string name;
    protected string surname;
    protected int age;

    public string Name { get => name; set => name = value; }
    public string Surname { get => surname; set => surname = value; }
    public int Age => age;

    public Person(string name, string surname, int age)
    {
        this.name = name;
        this.surname = surname;
        if (!SetPersonAge(age))
            throw new ArgumentException("Возраст должен быть от 15 до 70 лет.");
    }

    public bool SetPersonAge(int value)
    {
        if (value < 15 || value > 70) return false;
        age = value;
        return true;
    }

    protected void DisplayBasicInfo() =>
        Console.WriteLine($"{name} {surname}, возраст: {age}");

    protected internal string GetFullName() => $"{name} {surname}";

    private protected double CalculateStatistics(int count) =>
        count == 0 ? 0 : age / (double)count;
}

public class User : Person
{
    protected string role;
    private string confidentialNote;

    public string Role => role;

    public User(string name, string surname, int age, string role)
        : base(name, surname, age)
    {
        this.role = role;
        confidentialNote = "Служебная информация";
    }

    public string GetUserDescription() => $"{GetFullName()} — {role}";
}

public class Student : User
{
    private string group;
    private readonly int studentId;
    private static int nextId = 1;

    public string Group { get => group; set => group = value; }
    public int StudentId => studentId;

    public Student(string name, string surname, int age, string group)
        : base(name, surname, age, "Студент")
    {
        this.group = group;
        studentId = nextId++;
        ValidateStudentData();
    }

    private void ValidateStudentData()
    {
        if (string.IsNullOrWhiteSpace(Name) ||
            string.IsNullOrWhiteSpace(Surname) ||
            string.IsNullOrWhiteSpace(group))
            throw new ArgumentException("Данные студента не должны быть пустыми.");
        if (Age < 15 || Age > 70)
            throw new ArgumentException("Возраст должен быть от 15 до 70.");
    }

    public bool SetAge(int value) => SetPersonAge(value);

    public string GetStudentInfo() =>
        $"ID: {StudentId}, {Name} {Surname}, возраст: {Age}, группа: {Group}";

    public void ShowStudentInfo()
    {
        DisplayBasicInfo();
        Console.WriteLine($"Группа: {Group}, ID: {StudentId}");
        _ = CalculateStatistics(1);
    }
}

public class Teacher : User
{
    private string subject;
    private int experience;

    public string Subject { get => subject; set => subject = value; }
    public int Experience => experience;

    public Teacher(string name, string surname, int age, string subject, int experience)
        : base(name, surname, age, "Преподаватель")
    {
        this.subject = subject;
        UpdateExperience(experience);
    }

    public void UpdateExperience(int value)
    {
        if (value < 0 || value > 55)
            throw new ArgumentException("Стаж должен быть от 0 до 55 лет.");
        experience = value;
    }

    public string GetTeacherInfo()
    {
        DisplayBasicInfo();
        return $"{Name} {Surname}, предмет: {Subject}, стаж: {Experience} лет";
    }
}

public class Group
{
    private readonly List<Student> students = new();

    public string GroupName { get; private set; }
    public int Course { get; private set; }
    public IReadOnlyList<Student> Students => students.AsReadOnly();

    public Group(string groupName, int course, IEnumerable<Student>? initialStudents = null)
    {
        GroupName = groupName;
        Course = course;
        if (initialStudents != null)
            foreach (var student in initialStudents) AddStudent(student);
    }

    public bool AddStudent(Student student)
    {
        if (student == null || students.Any(s => s.StudentId == student.StudentId))
            return false;
        students.Add(student);
        return true;
    }

    public bool RemoveStudent(int studentId)
    {
        var student = students.FirstOrDefault(s => s.StudentId == studentId);
        return student != null && students.Remove(student);
    }
}

public class Subject
{
    private string title;
    private int hours;
    private Teacher? teacher;

    public string Title => title;
    public int Hours => hours;
    public Teacher? AssignedTeacher => teacher;

    public Subject(string title, int hours)
    {
        this.title = title;
        this.hours = hours;
    }

    public bool AssignTeacher(Teacher? newTeacher)
    {
        if (newTeacher == null) return false;
        teacher = newTeacher;
        return true;
    }
}

internal class CollegeSettings
{
    public string CollegeName { get; private set; }
    public string AcademicYear { get; private set; }

    public CollegeSettings(string collegeName, string academicYear)
    {
        CollegeName = collegeName;
        AcademicYear = academicYear;
    }

    internal void ChangeCollegeName(string value) => CollegeName = value;
    internal void ChangeAcademicYear(string value) => AcademicYear = value;
}

public class ReportManager
{
    protected internal string GenerateReport() => "Отчёт колледжа сформирован.";
}

public class CollegeReport : ReportManager
{
    public string Create() => GenerateReport();
}

public class UserAccount
{
    private string login;
    private string password;
    private bool isLoggedIn;

    public UserAccount(string login, string password)
    {
        this.login = login;
        this.password = password;
    }

    public bool Login(string enteredLogin, string enteredPassword)
    {
        isLoggedIn = login == enteredLogin && password == enteredPassword;
        return isLoggedIn;
    }

    public void Logout() => isLoggedIn = false;
    public string GetStatus() => isLoggedIn ? "Пользователь вошёл в систему." : "Пользователь не авторизован.";
}

public class Admin : User
{
    public Admin(string name, string surname, int age)
        : base(name, surname, age, "Администратор") { }
}

public class GradeBook
{
    private readonly List<int> grades = new();
    public IReadOnlyList<int> Grades => grades.AsReadOnly();

    public bool AddGrade(int grade)
    {
        if (grade < 2 || grade > 5) return false;
        grades.Add(grade);
        return true;
    }

    public bool RemoveGrade(int grade) => grades.Remove(grade);
    public double GetAverage() => grades.Count == 0 ? 0 : grades.Average();
}

public class AttendanceManager
{
    private readonly Dictionary<string, bool> attendance = new();

    public void AddAttendance(string studentName, bool present) =>
        attendance[studentName] = present;

    public bool UpdateAttendance(string studentName, bool present)
    {
        if (!attendance.ContainsKey(studentName)) return false;
        attendance[studentName] = present;
        return true;
    }

    public Dictionary<string, bool> GetStatistics() =>
        new Dictionary<string, bool>(attendance);

    public double GetAttendancePercent() =>
        attendance.Count == 0 ? 0 :
        attendance.Values.Count(x => x) * 100.0 / attendance.Count;
}

// ====================== РАБОТА С SQLITE ======================

public static class Database
{
    private static SqliteConnection Open(string connectionString)
    {
        var connection = new SqliteConnection(connectionString);
        connection.Open();
        return connection;
    }

    public static void Initialize(string connectionString)
    {
        using var connection = Open(connectionString);
        using var command = connection.CreateCommand();
        command.CommandText = """
        CREATE TABLE IF NOT EXISTS Students (
            Id INTEGER PRIMARY KEY AUTOINCREMENT,
            Name TEXT NOT NULL,
            Surname TEXT NOT NULL,
            Age INTEGER NOT NULL CHECK(Age BETWEEN 15 AND 70),
            GroupName TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS Teachers (
            Id INTEGER PRIMARY KEY AUTOINCREMENT,
            Name TEXT NOT NULL,
            Surname TEXT NOT NULL,
            Subject TEXT NOT NULL,
            Experience INTEGER NOT NULL
        );

        CREATE TABLE IF NOT EXISTS StudyGroups (
            Id INTEGER PRIMARY KEY AUTOINCREMENT,
            GroupName TEXT NOT NULL UNIQUE,
            Course INTEGER NOT NULL
        );

        CREATE TABLE IF NOT EXISTS Grades (
            Id INTEGER PRIMARY KEY AUTOINCREMENT,
            StudentName TEXT NOT NULL,
            Grade INTEGER NOT NULL CHECK(Grade BETWEEN 2 AND 5),
            Subject TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS Attendance (
            Id INTEGER PRIMARY KEY AUTOINCREMENT,
            StudentName TEXT NOT NULL,
            Present INTEGER NOT NULL
        );

        CREATE TABLE IF NOT EXISTS Users (
            Id INTEGER PRIMARY KEY AUTOINCREMENT,
            Login TEXT NOT NULL UNIQUE,
            Password TEXT NOT NULL,
            Role TEXT NOT NULL
        );
        """;
        command.ExecuteNonQuery();

        if (Count(connectionString, "Students") == 0)
        {
            Execute(connectionString, "INSERT INTO Students(Name,Surname,Age,GroupName) VALUES ($n,$s,$a,$g)",
                ("$n", "Айдана"), ("$s", "Серикова"), ("$a", 18), ("$g", "3 веб 1024"));
            Execute(connectionString, "INSERT INTO Students(Name,Surname,Age,GroupName) VALUES ($n,$s,$a,$g)",
                ("$n", "Арман"), ("$s", "Нурланов"), ("$a", 19), ("$g", "3 веб 1024"));
            Execute(connectionString, "INSERT INTO Students(Name,Surname,Age,GroupName) VALUES ($n,$s,$a,$g)",
                ("$n", "Дана"), ("$s", "Ермекова"), ("$a", 18), ("$g", "2 ПО 1024"));
        }

        if (Count(connectionString, "Teachers") == 0)
        {
            Execute(connectionString, "INSERT INTO Teachers(Name,Surname,Subject,Experience) VALUES ($n,$s,$p,$e)",
                ("$n", "Мадина"), ("$s", "Жумабекова"), ("$p", "PHP"), ("$e", 10));
            Execute(connectionString, "INSERT INTO Teachers(Name,Surname,Subject,Experience) VALUES ($n,$s,$p,$e)",
                ("$n", "Ерлан"), ("$s", "Садыков"), ("$p", "Java"), ("$e", 16));
        }

        if (Count(connectionString, "StudyGroups") == 0)
        {
            Execute(connectionString, "INSERT INTO StudyGroups(GroupName,Course) VALUES ($g,$c)",
                ("$g", "3 веб 1024"), ("$c", 3));
            Execute(connectionString, "INSERT INTO StudyGroups(GroupName,Course) VALUES ($g,$c)",
                ("$g", "2 ПО 1024"), ("$c", 2));
        }

        if (Count(connectionString, "Grades") == 0)
        {
            Execute(connectionString, "INSERT INTO Grades(StudentName,Grade,Subject) VALUES ($n,$g,$s)",
                ("$n", "Айдана Серикова"), ("$g", 5), ("$s", "PHP"));
            Execute(connectionString, "INSERT INTO Grades(StudentName,Grade,Subject) VALUES ($n,$g,$s)",
                ("$n", "Арман Нурланов"), ("$g", 4), ("$s", "Java"));
            Execute(connectionString, "INSERT INTO Grades(StudentName,Grade,Subject) VALUES ($n,$g,$s)",
                ("$n", "Дана Ермекова"), ("$g", 5), ("$s", "PHP"));
        }

        if (Count(connectionString, "Attendance") == 0)
        {
            Execute(connectionString, "INSERT INTO Attendance(StudentName,Present) VALUES ($n,$p)",
                ("$n", "Айдана Серикова"), ("$p", 1));
            Execute(connectionString, "INSERT INTO Attendance(StudentName,Present) VALUES ($n,$p)",
                ("$n", "Арман Нурланов"), ("$p", 0));
            Execute(connectionString, "INSERT INTO Attendance(StudentName,Present) VALUES ($n,$p)",
                ("$n", "Дана Ермекова"), ("$p", 1));
        }

        if (Count(connectionString, "Users") == 0)
        {
            Execute(connectionString, "INSERT INTO Users(Login,Password,Role) VALUES ($l,$p,$r)",
                ("$l", "admin"), ("$p", "12345"), ("$r", "Admin"));
        }
    }

    private static void Execute(string cs, string sql, params (string key, object value)[] parameters)
    {
        using var connection = Open(cs);
        using var command = connection.CreateCommand();
        command.CommandText = sql;
        foreach (var p in parameters) command.Parameters.AddWithValue(p.key, p.value);
        command.ExecuteNonQuery();
    }

    public static int Count(string cs, string table)
    {
        string[] allowed = { "Students", "Teachers", "StudyGroups", "Grades", "Attendance", "Users" };
        if (!allowed.Contains(table)) throw new ArgumentException("Недопустимая таблица.");
        using var connection = Open(cs);
        using var command = connection.CreateCommand();
        command.CommandText = $"SELECT COUNT(*) FROM {table}";
        return Convert.ToInt32(command.ExecuteScalar());
    }

    public static bool CheckLogin(string cs, string login, string password)
    {
        using var connection = Open(cs);
        using var command = connection.CreateCommand();
        command.CommandText = "SELECT COUNT(*) FROM Users WHERE Login=$login AND Password=$password";
        command.Parameters.AddWithValue("$login", login);
        command.Parameters.AddWithValue("$password", password);
        return Convert.ToInt32(command.ExecuteScalar()) > 0;
    }

    public static void AddStudent(string cs, string name, string surname, int age, string groupName) =>
        Execute(cs, "INSERT INTO Students(Name,Surname,Age,GroupName) VALUES ($n,$s,$a,$g)",
            ("$n", name), ("$s", surname), ("$a", age), ("$g", groupName));

    public static List<StudentRow> GetStudents(string cs)
    {
        var result = new List<StudentRow>();
        using var connection = Open(cs);
        using var command = connection.CreateCommand();
        command.CommandText = "SELECT Id,Name,Surname,Age,GroupName FROM Students ORDER BY Id";
        using var reader = command.ExecuteReader();
        while (reader.Read())
            result.Add(new StudentRow(reader.GetInt32(0), reader.GetString(1), reader.GetString(2),
                reader.GetInt32(3), reader.GetString(4)));
        return result;
    }

    public static List<TeacherRow> GetTeachers(string cs)
    {
        var result = new List<TeacherRow>();
        using var connection = Open(cs);
        using var command = connection.CreateCommand();
        command.CommandText = "SELECT Name,Surname,Subject,Experience FROM Teachers ORDER BY Id";
        using var reader = command.ExecuteReader();
        while (reader.Read())
            result.Add(new TeacherRow(reader.GetString(0), reader.GetString(1), reader.GetString(2), reader.GetInt32(3)));
        return result;
    }

    public static List<GroupRow> GetGroups(string cs)
    {
        var result = new List<GroupRow>();
        using var connection = Open(cs);
        using var command = connection.CreateCommand();
        command.CommandText = """
            SELECT g.GroupName, g.Course, COUNT(s.Id)
            FROM StudyGroups g LEFT JOIN Students s ON s.GroupName = g.GroupName
            GROUP BY g.Id, g.GroupName, g.Course ORDER BY g.Id
            """;
        using var reader = command.ExecuteReader();
        while (reader.Read())
            result.Add(new GroupRow(reader.GetString(0), reader.GetInt32(1), reader.GetInt32(2)));
        return result;
    }

    public static List<GradeRow> GetGrades(string cs)
    {
        var result = new List<GradeRow>();
        using var connection = Open(cs);
        using var command = connection.CreateCommand();
        command.CommandText = "SELECT StudentName,Grade,Subject FROM Grades ORDER BY Id";
        using var reader = command.ExecuteReader();
        while (reader.Read())
            result.Add(new GradeRow(reader.GetString(0), reader.GetInt32(1), reader.GetString(2)));
        return result;
    }

    public static List<AttendanceRow> GetAttendance(string cs)
    {
        var result = new List<AttendanceRow>();
        using var connection = Open(cs);
        using var command = connection.CreateCommand();
        command.CommandText = "SELECT StudentName,Present FROM Attendance ORDER BY Id";
        using var reader = command.ExecuteReader();
        while (reader.Read())
            result.Add(new AttendanceRow(reader.GetString(0), reader.GetInt32(1) == 1));
        return result;
    }
}

public record StudentRow(int Id, string Name, string Surname, int Age, string GroupName);
public record TeacherRow(string Name, string Surname, string Subject, int Experience);
public record GroupRow(string GroupName, int Course, int StudentCount);
public record GradeRow(string StudentName, int Grade, string Subject);
public record AttendanceRow(string StudentName, bool Present);
